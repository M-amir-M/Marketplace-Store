@extends('layouts.main')

@section('content')
    <div id="homepage">
        <router-view></router-view>
    </div>
@endsection