@extends('layouts.main')

@section('content')
    <router-view></router-view>
@endsection